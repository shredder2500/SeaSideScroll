using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using ModestTree;

namespace Zenject
{
    public interface ISignal : IDisposable
    {
    }
}
