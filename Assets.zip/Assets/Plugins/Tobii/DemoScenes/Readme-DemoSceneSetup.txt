Tobii EyeTracking SDK - Demo Scene Setup in Unity
=================================================

## Add Demo Scenes to Build
Before you run the demo scenes, add them to the project build:
`Tools` -> `Add Tobii SDK Demo Scenes To Build`

This makes sure the navigation between scenes works without "scene not found" errors.

## Further information
For more information on getting started and troubleshooting, see:
Assets/Tobii/Readme.txt