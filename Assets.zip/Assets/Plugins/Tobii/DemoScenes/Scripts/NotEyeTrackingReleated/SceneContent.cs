﻿using System;
using UnityEngine;

public class SceneContent : MonoBehaviour
{
    public string Headline;
    public string Description;
    public string InteractionTip;
    public bool HasSuggestion;
}
